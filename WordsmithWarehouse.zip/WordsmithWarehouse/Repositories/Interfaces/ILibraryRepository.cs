﻿using ClassLibrary.Entities;

namespace WordsmithWarehouse.Repositories.Interfaces
{
    public interface ILibraryRepository : IGenericRepository<Library>
    {
    }
}
