﻿namespace WordsmithWarehouse.Models
{
    public class GlobalViewModel
    {
        public string UserImageURL { get; set; }
    }
}
