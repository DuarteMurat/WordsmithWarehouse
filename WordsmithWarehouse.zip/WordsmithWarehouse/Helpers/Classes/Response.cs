﻿namespace WordsmithWarehouse.Helpers.Classes
{
    public class Response
    {
        public bool IsSuccess { get; set; }

        public string Message { get; set; }

        public object Results;
    }
}
